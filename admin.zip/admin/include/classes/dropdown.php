<?php 
    class exam {    

 $id;
 $name;
 $date;

 


}   
        
  ?>