<?php


include('../config/dbconnection.php');
$pid = $_POST['pid'];
$rimg = trim($_POST['imgrule']);
$insert = $db->query("UPDATE `examruleandterm` SET `imgrule`= '$rimg' WHERE `paperid` = $pid"); 
$insert->execute();
if($insert){ 
echo "Added Successfully";
}else{ 
echo "Something Went Wrong!!";
}
?>