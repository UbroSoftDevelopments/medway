<?php
    include('../config/dbconnection.php');

$langid = $_POST['langid'];
$list = $_POST['dt'];
$secid = $_POST['secid'];
//echo "vb".count($list).",".$langid.",".$secid;

    
    for($i=0;$i<count($list);$i++){

    $qid = $list[$i]['qid'];
    $type = $list[$i]['types'];
    $mms = $list[$i]['mms'];
    $nms = $list[$i]['nms'];
    $ol1 = $list[$i]['ol1'];
    $ol2 = $list[$i]['ol2'];
    $ol3 = $list[$i]['ol3'];
    $ol4 = $list[$i]['ol4'];
    $question = $list[$i]['question'];
    $opt1 = $list[$i]['opt1'];
    $opt2 = $list[$i]['opt2'];
    $opt3 = $list[$i]['opt3'];
    $opt4 = $list[$i]['opt4'];
    $explain = $list[$i]['explain'];

            $insert = $db->query("UPDATE `question` SET `explanation`='$explain', `type`=$type, `mm`=$mms, `nm`=$nms WHERE id = $qid"); 
                if($insert){             
                    // echo "Data Inserted".$i;
                    $sql = "INSERT INTO `questionimgbylanguage`(`qid`, `langid`, `data`) VALUES (:qid,:langid,:qdata)";
                    $r = $db->prepare($sql);
                    $insertvisitor = $r->execute(array( ':qid'=> $qid, ':langid'=>$langid, ':qdata'=>$question));             
                    if($insertvisitor){                        
                        
                        // begin the transaction
                        $db->beginTransaction();
                        // our SQL statements
                        $db->exec("INSERT INTO `optionimgbylanguage`(`opid`,`langid`,`data`)
                        VALUES ($ol1, $langid, '$opt1')");
                        $db->exec("INSERT INTO `optionimgbylanguage`(`opid`,`langid`,`data`)
                        VALUES ($ol2, $langid, '$opt2')");
                        $db->exec("INSERT INTO `optionimgbylanguage`(`opid`,`langid`,`data`)
                        VALUES ($ol3, $langid, '$opt3')");
                        $db->exec("INSERT INTO `optionimgbylanguage`(`opid`,`langid`,`data`)
                        VALUES ($ol4, $langid, '$opt4')");

                        // commit the transaction
                        $db->commit();        
                        //echo "New records created successfully";
                            
                    }
                }
    }
 
            
            

?>