<?php
header('Content-Type: application/json');
    include('../config/dbconnection.php');
    $psid = $_POST['psid'];

    $res = array(
      'status' => true,
      'msg' => 'Result List',
      'data' => ''
    );
  $output = ' <div class="card">
              <div class="card-body">
              <table class="table table-bordered table-striped" id="canditable">
               <thead style="background-color: black;">
                <tr>                
                  <th class="text-white">#</th>
                  <th class="text-white">Name</th>
                  <th class="text-white">Enrollmentno</th>
                  <th class="text-white">Alloted Time</th>
                  <th class="text-white">Set No</th>
                  <th class="text-white">Shift</th>
                </tr>
                </thead>
                <tbody>';
                
  

    $result = $db->prepare("SELECT *,(Select name from candidate where id=ex.candidateid) cname, 
    (Select photo from candidatephotomaster where candidateid=ex.enrollmentno) photo, 
    (Select shifttime from papershift where id=ex.papershiftid) shifttime FROM `examcandidate` ex where papershiftid = $psid");
      $result->execute();
      
      for($j=1;$row=$result->fetch();$j++){
        $output .="
        <tr>
            <td>".$j."</td>
            <td>".$row['cname']."</td>
            <td>".$row['enrollmentno']."</td>
            <td>".$row['allotedtime']."</td>
            <td>".$row['setno']."</td>
            <td>".$row['shifttime']."</td>
        </tr>";
      }  
      $output .= '</tbody></table></div></div>';

  $res['data'] = $output;
  echo json_encode($res);
?>