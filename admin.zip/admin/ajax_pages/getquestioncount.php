<?php 
header('Content-Type: application/json');
$psid = $_POST['psid'];

 include('../config/dbconnection.php');
  $result = $db->prepare("SELECT secid, COUNT(id) as count FROM `question` where papershiftid = $psid GROUP by secid"); 
      $result->execute();
      $spsp = $result->fetchAll(PDO::FETCH_ASSOC);
      $photoarray = json_encode($spsp,JSON_NUMERIC_CHECK);

      echo $photoarray;

?>

    

   


